<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Task 4</title>
	<link rel="stylesheet" href="CSS/bootstrap.min.css">
</head>
<body class="bg-success">
	<div class="container m-5 ">
		<h1 class="text-center">User Information</h1>
		<div class="row d-flex justify-content-center bg-light p-3 m-3">
			<div class="col-md-6 ">
            <div class="card" style="width: 18rem;">
  <img src="..." class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card’s content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
	</div>
	
	<script src="JS/jquery.slim.min.js"></script>
	<script src="JS/popper.min.js"></script>
	<script src="JS/bootstrap.min.js"></script>
</body>
</html>