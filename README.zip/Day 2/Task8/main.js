function PrintName(){
    let username=document.getElementById("username").value;
    document.getElementById("output").innerHTML="Hello "+username+",We Are Pleasure To See You Today.";
    document.getElementById("output").style.color="white";
    document.getElementById("output").style.backgroundColor="red";
    document.getElementById("output").style.padding="10px 20px";
    document.getElementById("output").style.borderRadius="10px";
}
