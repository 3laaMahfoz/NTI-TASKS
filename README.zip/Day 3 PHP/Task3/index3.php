<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task One Day 3 php</title>
</head>
<body>
     <?php

        // task one ==>
        echo "omar ahmed elsharkawi<br>";
        print "اول سطر لي باستخدام php<br>";
        echo "<hr>";
        // task two==>
        $n1=12;
        $n2=10;
        echo "the summtion is:".($n1 +$n2)."<br>";
        echo "the change is:".($n1 %$n2)."<br>";

     ?>
</body>
</html>
