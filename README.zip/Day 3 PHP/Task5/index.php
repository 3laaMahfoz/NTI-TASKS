<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>D3-T5</title>
</head>
<body>
        <?php
            // <!-- task four==> -->
                for($i=0;$i<=20;$i+=5)
                echo $i ."<br>";
                echo "<hr>";
                for($i=0;$i<=20;$i++){
                if($i%5==0){
                    echo $i."<br>";
                }
                } 
        ?>
</body>
</html>